import 'package:flutter/material.dart';

class DoctorPage extends StatefulWidget{
  DoctorPage();

@override
DoctorPageState createState()=> DoctorPageState();
}

class DoctorPageState extends State<DoctorPage>{

  @override
  Widget build(BuildContext context){
    return Container();
  }
}