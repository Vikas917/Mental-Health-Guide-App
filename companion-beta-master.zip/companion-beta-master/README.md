# companion_beta

An app that asks daily questions and then provides a best estimate of the mental condition of the user. It also suggests steps that can be taken to counter a possible health problem. It tracks the mood on a weekly basis and if it finds that the user's condition isn't improving, it refers a list of doctors within the app. 

## Medium article
Check out the article I wrote for companion and companion beta
app here: https://medium.com/@WJayesh/going-from-scratch-to-a-full-blown-flutter-app-in-two-days-c06f1d1a1975

## Video Demo
Check out a demo of the app on my channel on YouTube:

[![IMAGE ALT TEXT](http://img.youtube.com/vi/AdQA9cpkRCk/0.jpg)](http://www.youtube.com/watch?v=AdQA9cpkRCk "Video Title")
